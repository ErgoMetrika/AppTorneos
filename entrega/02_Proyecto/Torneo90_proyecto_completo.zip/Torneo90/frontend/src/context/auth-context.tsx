import type { Session } from '@supabase/supabase-js'
import { useQueryClient } from '@tanstack/react-query'
import { createContext, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from 'react'

import { getProfile } from '@/lib/api'
import { supabase } from '@/lib/supabase'
import type { PerfilUsuario } from '@/types/domain'

interface AuthContextValue {
  session: Session | null
  profile: PerfilUsuario | null
  loading: boolean
  isAdmin: boolean
  signOut: () => Promise<void>
}

const AuthContext = createContext<AuthContextValue | undefined>(undefined)

export function AuthProvider({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<Session | null>(null)
  const [profile, setProfile] = useState<PerfilUsuario | null>(null)
  // Ya se sabe si hay sesión (primer getSession resuelto)
  const [sessionReady, setSessionReady] = useState(false)
  // Usuario cuyo perfil ya se terminó de leer: mientras no coincida con la sesión, el rol no se conoce
  const [profileFor, setProfileFor] = useState<string | null>(null)
  const queryClient = useQueryClient()
  // Usuario de la sesión anterior: si cambia (logout o login con otra cuenta),
  // se vacía la caché para no mostrar datos del usuario anterior.
  const lastUserId = useRef<string | null | undefined>(undefined)

  useEffect(() => {
    let active = true

    const onUserChange = (nextSession: Session | null) => {
      const nextUserId = nextSession?.user.id ?? null
      if (lastUserId.current !== undefined && lastUserId.current !== nextUserId) {
        queryClient.clear()
        setProfile(null)
      }
      lastUserId.current = nextUserId
    }

    supabase.auth.getSession().then(({ data }) => {
      if (!active) return
      onUserChange(data.session)
      setSession(data.session)
      setSessionReady(true)
    })

    const { data: listener } = supabase.auth.onAuthStateChange((_event, nextSession) => {
      onUserChange(nextSession)
      setSession(nextSession)
      setSessionReady(true)
      if (!nextSession) {
        setProfile(null)
        setProfileFor(null)
      }
    })

    return () => {
      active = false
      listener.subscription.unsubscribe()
    }
  }, [queryClient])

  const userId = session?.user.id
  useEffect(() => {
    if (!userId) return
    // Si cambia el usuario (o se desmonta) antes de que llegue la respuesta, la descartamos:
    // así un perfil viejo no pisa el de la sesión actual
    let active = true
    getProfile(userId)
      .then((nextProfile) => {
        if (active) setProfile(nextProfile)
      })
      .catch(() => {
        // Sin perfil no hay rol: queda en null y la app se comporta como usuario sin datos
        if (active) setProfile(null)
      })
      .finally(() => {
        if (active) setProfileFor(userId)
      })
    return () => {
      active = false
    }
  }, [userId])

  // Cargando hasta saber la sesión y, si hay usuario, su rol. Sin esto, justo después de entrar
  // el admin se veía un instante como jugador y las guardas lo mandaban a la vista del jugador.
  const loading = !sessionReady || (Boolean(userId) && profileFor !== userId)

  const value = useMemo<AuthContextValue>(
    () => ({
      session,
      profile,
      loading,
      isAdmin: profile?.rol === 'admin',
      signOut: async () => {
        await supabase.auth.signOut()
        queryClient.clear()
      },
    }),
    [loading, profile, session, queryClient],
  )

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (!context) throw new Error('useAuth debe usarse dentro de AuthProvider')
  return context
}
